function trigger()
{
    document.getElementById("nose").addEventListener("click", popup);
}

function popup()
{
    alert("Solo SANTA FE");
}